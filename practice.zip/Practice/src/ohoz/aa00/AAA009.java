package ohoz.aa00;

/*
 * Given a 9�9 sudoku we have to evaluate it for its correctness. We have to check both the sub matrix correctness and the whole sudoku correctness.
 */
public class AAA009 {

}
