package ohoz.aa01;

/*
 * Insert 0 after consecutive (K times) of 1 is found.
Example:

Input:
Number of bits: 12
Bits: 1 0 1 1 0 1 1 0 1 1 1 1
Consecutive K: 2

Output:
1 0 1 1 0 0 1 1 0 0 1 1 0 1 1 0
 */
public class AAA015 {

}
