package ohoz.aa01;

/*
 *  Print only numbers which is present in Fibonacci series (0 1 1 2 3 5 8 ��..)

Example:

Input: 2 10 4 8
Output: 2 8 
Input: 1 10 6 8 13 21
Output: 1 8 13 21
 */
public class AAA012 {
	
	public static void main(String[] args) {
		
		for (int i = 0; i < args.length; i++) {
			
		}
	}

}
