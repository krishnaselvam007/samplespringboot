package ohoz.aa01;
/*
 * Given four points, We have to say whether it is square or rectangle or any other shape
 */
public class AAA018 {

}
