package ohoz.aa01;

/*
 * To implement snake and ladder game for given two-dimensional array having position of snakes and ladders
 */
public class AAA017 {

}
