package ohoz.aa02;
/*
 Given a 2D grid of characters, you have to search for all the words in a dictionary by
moving only along two directions, either right or down. Print the word if it occurs.
 
Sample :         
  a   z  o   l 
  n   x  h   o
  v   y   i   v 
  o   r   s  e 
 Dictionary = {van, zoho, love, are, is} 
 
 Output: 
    zoho 
    love 
    Is 
 */
public class AAA030 {

}
