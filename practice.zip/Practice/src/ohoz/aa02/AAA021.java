package ohoz.aa02;
/*
 Print all possible combinations from the given string.
 */
public class AAA021 {

}
