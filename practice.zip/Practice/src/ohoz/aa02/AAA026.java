package ohoz.aa02;
/*
 They gave a passage and the output should be printing out the number of occurrence of each word and the indices it occurs without using string matching

The passage given was �jana Gana Mana� and so on.. and we have to print number of jana and it�s indices.i.e at which position it occurs.

 */
public class AAA026 {

}
