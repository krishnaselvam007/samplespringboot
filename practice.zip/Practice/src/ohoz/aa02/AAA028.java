package ohoz.aa02;
/*
 Find the largest sum contiguous subarray which should not have negative numbers. We have to print the sum and the corresponding array elements which brought up the
sum.

 
Sample: 
Array : {�2, 7, 5, �1, 3, 2, 9, �7} 

Output: 
     Sum : 14 
     Elements : 3, 2, 9  
 */
public class AAA028 {

}
