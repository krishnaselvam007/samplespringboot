package ohoz.aa02;
/*
 Enter two strings from command line and check whether any substring present in first string that follows the pattern of second sting.. They asked to implement  regular expressions for * and backslash without built in functions.

�abcd� �a*cd� answer : yes
�aaaa� �a*�  answer : yes
�a*c� �a\*c� answer:yes
�adsd� �ad� answer:no
 */
public class AAA025 {

}
