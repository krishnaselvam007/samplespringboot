package ohoz.aa02;
/*
  Given a sliding window of size k print the maximum of the numbers under the sliding window.
Example: Consider a sliding window of size k equals 3. Let the array be [3,2,7,6,5,1,2,3,4] the output should print 7 as the first output as first window contains {3,2,7} and second window contains {2,7,6} and so on and the final output is {7,7,7,6,5,3,4}
 */
public class AAA023 {

}
