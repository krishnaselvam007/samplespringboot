package ohoz.aa02;
/*
 Given a string, we have to reverse the string without changing the position of punctuations and spaces.

 
Sample:   house no : 123@ cbe 
Output:    ebc32 1o :  nes@ uoh 
 */
public class AAA029 {

}
