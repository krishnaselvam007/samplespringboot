package ohoz.aa04;

/*
Given a sentence of string, in that remove the palindrome words and print the remaining.
Input:
He did a good deed
Output:
He good

Input:
Hari speaks malayalam
Output:
Hari speaks

 */
public class AAA043 {

}
