package ohoz.aa04;

/*
Sort the array alternately i.e first element should be max value, second min value, third second max, third second min. Eg: arr[] = {1,2,3,4,5,6,7} O/P: {7,1,6,2,5,3,4} Note: no extra space and time complexity should be less;
 */
public class AAA048 {

}
