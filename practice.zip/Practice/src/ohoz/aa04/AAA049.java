package ohoz.aa04;

/*
Print all the substring of the given string.
 */
public class AAA049 {

}
