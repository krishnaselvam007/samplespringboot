package ohoz.aa04;

/*
Print the numbers which are mismatched from two array. Arr1 = {a b c d e f g h i}
arr2 ={ a b d e e g g i i}, O/P- cd, de, f, g, h, i.
 */
public class AAA050 {

}
