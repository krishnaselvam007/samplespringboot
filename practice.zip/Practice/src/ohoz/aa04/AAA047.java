package ohoz.aa04;

/*
1. Spiral printing.
O/P
4444444
4333334
4322234
4321234
4322234
4333334
4444444
 */
public class AAA047 {

}
