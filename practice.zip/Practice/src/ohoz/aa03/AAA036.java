package ohoz.aa03;

/*
form the largest possible number using the array of numbers.
lexicographic sorting.
given a set of numbers, and a digit in each iteration, if the digit exists in any of  the numbers, remove its occurrences and ask for the next digit till the list becomes empty.
Check if a number �a� is present in another number �b.
 */
public class AAA036 {

}
