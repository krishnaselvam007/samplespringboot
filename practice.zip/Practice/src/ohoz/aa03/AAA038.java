package ohoz.aa03;

/*
Find the least prime number that can be added with first array element that makes them divisible by second array elements at respective index (check for prime numbers under 1000, if exist return -1 as answer) & (Consider 1 as prime number)

Input : [ 20, 7 ]
    [ 11, 5 ]
Output : [ 1, 3 ]

Explanation : 
(20 + ?) % 11 
( 7 + ?) % 5
 */
public class AAA038 {

}
