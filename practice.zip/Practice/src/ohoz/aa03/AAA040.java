package ohoz.aa03;

/*
Print true if second string is a substring of first string, else print false.

Note : * symbol can replace n number of characters
Input : Spoon  Sp*n  Output : TRUE
    Zoho     *o*o  Output : TRUE
    Man       n*     Output : FALSE
    Subline  line   Output : TRUE
 */
public class AAA040 {

}
