package ohoz.aa03;

/*
prime number � print n prime numbers
 */
public class AAA033 {

}
