package ohoz.aa03;

/*

prime factor � sort the array based on the minimum factor they have.
 */
public class AAA034 {

}
