package ohoz.aa03;

/*
Print the following pattern

   1  
  3 2
 6 5 4
10 9 8 7
10 9 8 7 
 6 5 4 
  3 2 
   1
 */
public class AAA031 {

}
