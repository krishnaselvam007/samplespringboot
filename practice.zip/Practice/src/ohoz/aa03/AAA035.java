package ohoz.aa03;

/*

adding a digit to all the digits of a number eg digit=4, number = 2875, o/p= 612119
 */
public class AAA035 {

}
