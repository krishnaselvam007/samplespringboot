package ohoz.aa03;

/*
Sort the array elements in descending order according to their frequency of occurrence 

Input : [ 2 2 3 4 5 12 2 3 3 3 12 ]
Output : 3 3 3 3 2 2 2 12 12 4 5
Explanation : 3 occurred 4 times, 2 occurred 3 times, 12 occurred 2 times, 4 occurred 1 time, 5 occurred 1 time

Input : [ 0 -1 2 1 0 ]
Output : 0 0 -1 1 2
Note : sort single occurrence elements in ascending order

 */
public class AAA039 {

}
